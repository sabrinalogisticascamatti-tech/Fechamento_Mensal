// Gemini Service - Optimized
const apiKey = import.meta.env.VITE_GEMINI_API_KEY;
export const geminiService = { /* ...optimized code... */ };
